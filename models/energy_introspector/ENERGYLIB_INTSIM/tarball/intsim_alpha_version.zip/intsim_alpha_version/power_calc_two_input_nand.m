function [ leakage_power_two_input_nand dyn_power_two_input_nand ] = power_calc_two_input_nand(device_width, F,tox, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, Vdd, Vt, f)
%power_calc_two_input_nand This computes the leakage and dynamic power of a minimum feature size two input NAND gate
% Helps find the total power of a minimum feature size 2 input NAND gate

% Find the total capacitance of the device assuming nmos and pmos devices are equally sized
eo = 8.854e-12;
Cox = 3.9.*eo./tox;
C_device = 4.*(F.^2).*Cox;
%C_device = C_device./2; %ONLY FOR MEROM!

% Computes dynamic power
dyn_power_two_input_nand = .5.*a.*device_width.*C_device.*Vdd.^2.*f;

% Computes leakage power since leakage width of a nand gate is 1.125 times the width of the minimum feature size transistor
% Reference: BACPAC manual
leakage_power_two_input_nand = 1.125.*device_width.*Vdd.*Ileak_spec./(10.^(-Vt_spec./subvtslope_spec)).*(10.^(-Vt./subvtslope_spec));
