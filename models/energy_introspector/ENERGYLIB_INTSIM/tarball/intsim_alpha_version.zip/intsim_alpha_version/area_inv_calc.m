function [ area_inv ] = area_inv_calc( F, device_width )
%area_inv Calculates the area of an inverter
%   This function could be useful for calculating repeater area

%------------------------------------------------------------------------
%   Reference: R. Venkatesan, PhD thesis, Georgia Tech, 2003
%   Available at www.ece.gatech.edu/research/labs/gsigroup under the
%   publications section
%------------------------------------------------------------------------

ki=102;
gar = 17./6;
fi = 1;
betag = 2./fi;
area_inv =  ki.*(1+4.*gar.^.5.*(fi-1)./ki.^.5).*(1+(1+betag).*(device_width-1)./(ki.*gar).^.5).*F.^2;

