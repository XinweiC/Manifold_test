function [ W reach_clock_frequency_flag pgates] = two_input_nand_gate_sizing(ngates, A, cg, cm, ro, tox, F, ncp, f, margin, drive_p_div_n, k, p, fo)
%two_input_nand_gate_sizing Sizes NAND gates
% Sizes NAND gates based on logic depth, etc
% Effective fan-in of series connected MOSFETs is 1.5 for a 2 input NAND gate


% Resistance and capacitance of nMOS transistors in the NAND gate are computed
rnmos = ro;
eo = 8.854e-12;
Cox = 3.9.*eo./tox;
cnmos = (F.^2).*Cox;
%cnmos = cnmos./2; %ONLY FOR MEROM!

% Resistance and capacitance of pMOS transistors in the NAND gate are computed
rpmos = rnmos./drive_p_div_n;
cpmos = cnmos;


% Total input capacitance of a 2 input NAND gate assuming pMOS and nMOS are sized the same
cnand = 2.*cnmos + 2.* cpmos;

for wgate = 1:1:40

% Finds the percentage of chip area taken by logic gates for a certain wgate    
pgates = ngates.*area_two_input_nand_gate_calc( F, wgate )./A;

% Average wire capacitance for a certain wgate
av_wire_cap = av_wire_cap_calc( cg, cm, k, p, A, ngates, pgates, fo );

% Delay when the nMOS transistor drives the interconnect
t_nmos = 1./(1-margin).*ncp.*(1.5.*0.7.*rnmos./wgate.*(cnand.*wgate.*fo+av_wire_cap));

% Worst case delay when the pMOS transistor drives the interconnect
t_pmos = 1./(1-margin).*ncp.*(0.7.*rpmos./wgate.*(cnand.*wgate.*fo+av_wire_cap));

% Average delay of the critical path 
td = .5.*(t_nmos + t_pmos);

% Clock frequency that can be attained for a certain wgate
allowed_clock_frequency = 1./td;

% Flag which says clock frequency cannot be attained
reach_clock_frequency_flag = 0;

% If the allowed clock frequency for a certain wgate is higher than the required frequency, choose that wgate as the logic gate size
if allowed_clock_frequency>f  
        W=wgate;
        break;
else
    reach_clock_frequency_flag=1;
    W=0;
end

end
