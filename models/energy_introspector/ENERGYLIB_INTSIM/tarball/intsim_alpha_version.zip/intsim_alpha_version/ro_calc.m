function [ ro ] = ro_calc( Vdd, Vt, Vdd_spec, Vt_spec, Idsat_spec, alpha )
%ro Computes the output resistance of a minimum size inverter
%  ro is the output resistance of a minimum size repeater

%  Reference: BACPAC manual

ro = 0.8.*Vdd/(Idsat_spec./((Vdd_spec-Vt_spec).^alpha).*(Vdd-Vt).^alpha);
