function [ area_two_input_nand_gate ] = area_two_input_nand_gate_calc( F, device_width )
%area_inv Calculates the area of a two input NAND gate
%   This function could be useful for calculating area of critical path gates

%------------------------------------------------------------------------
%   Reference: R. Venkatesan, PhD thesis, Georgia Tech, 2003
%   Available at www.ece.gatech.edu/research/labs/gsigroup under the
%   publications section
%------------------------------------------------------------------------

ki=102;
gar = 17./6;
fi = 2;
betag = 2./fi;
area_two_input_nand_gate =  ki.*(1+4.*gar.^.5.*(fi-1)./ki.^.5).*(1+(1+betag).*(device_width-1)./(ki.*gar).^.5).*F.^2;

