function [ cg ] = cg_calc( W, T, H, S, er )
%cg_calc Computes the ground capacitance per unit length of a wire
%   H is the ILD thickness, S is the spacing between wires, T is the wire thickness, W is the wire width

%------------------------------------------------------------------------
%   Reference: R. Venkatesan, PhD thesis, Georgia Tech, 2003
%   Available at www.ece.gatech.edu/research/labs/gsigroup under the
%   publications section
%------------------------------------------------------------------------

eo = 8.854e-12;
cg = er.*eo.*(W./H+1.086.*(1+.685.*2.718.^(-T./1.343./S)-.9964.*2.718.^(-S./1.421./H)).*((S./(S+2.*H)).^(0.0476)).*(T./H).^.337);
