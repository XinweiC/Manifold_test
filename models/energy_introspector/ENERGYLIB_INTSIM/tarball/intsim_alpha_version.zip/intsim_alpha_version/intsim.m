%===============================================================================================================================================================
%                                                                                                                                                              %
%                                                                                                                                                              %
%                                                                         IntSim                                                                               %
%                                                                                                                                                              %
%                                                                                                                                                              % 
%===============================================================================================================================================================




%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% GOALS OF INTSim
%
% (1) To obtain an optimal multilevel interconnect architecture based on a co-design of signal, power, clock and thermal interconnect networks
% (2) Optimize and tradeoff die area-number of wiring levels-frequency-power-temperature-Vdd-Vt 
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------





%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% PRELIMINARIES

% Clears out all variables
clear;

% Runs the GUI program
gui;

%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------







%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% PARAMETER DEFINITIONS


% System-level parameters

system_parameters = {'Please enter system parameters                                                                                                            Supply voltage (in V):','Threshold voltage (in V):', 'Frequency (in GHz):', 'Logic depth (number of 2 input NAND gates):', 'Rents constant k:', 'Rents constant p:', 'Activity factor:', 'Die area (in sq mm):', 'Number of gates (in millions):'     };
dlg_title = 'Enter system parameters';
num_lines = 1;
def = {'0.5','0.2', '8', '10','4', '0.6', '0.1','35', '58'};
options.Resize = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
answer = inputdlg(system_parameters,dlg_title,num_lines,def, options);

Vdd       = str2double(answer{1});                          % Supply voltage                                          (in V)
Vt        = str2double(answer{2});                          % Threshold voltage                                       (in V)
f         = str2double(answer{3}).*1e9;                     % Clock frequency                                         (in Hz)
ncp       = str2double(answer{4});                          % Number of gates on a critical path
k         = str2double(answer{5});                          % Rent's constant k
p         = str2double(answer{6});                          % Rent's constant p
a         = str2double(answer{7});                          % Activity factor
A         = str2double(answer{8}).*1e-6;                    % Die area                                                (in m2)
ngates    = str2double(answer{9}).*1e6;                     % Number of gates                                         (in M)

% Device technology parameters

device_parameters = {'Please enter device technology parameters                                                                                                   Minimum feature size (in nm):','Saturation drain current of a nFET (in A/m):', 'Leakage current of a nFET (in A/m):', 'Vdd at which currents are specified (in V):', 'Vt at which currents are specified (in V):', 'Effective oxide thickness (in nm)', 'Alpha', 'Ratio of drive currents of pMOS to nMOS', 'Sub-threshold slope at 85 degree C (in mV/dec)'     };
dlg_title = 'Enter device technology parameters';
num_lines = 1;
def = {'22','760', '.2', '.5','0.24', '1.1', '1.3','0.5', '100'};
options.Resize = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
answer1 = inputdlg(device_parameters,dlg_title,num_lines,def, options);

F          = str2double(answer1{1}).*1e-9;                   % Minimum feature size                                    (in m)
Idsat_spec = str2double(answer1{2}).*F;                      % Saturation drain current for a minimum size NFET        (in A)
Ileak_spec = str2double(answer1{3}).*F;                      % Leakage current of a minimum size NFET                  (in A)
Vdd_spec   = str2double(answer1{4});                         % Vdd at which Idsat and Ileak are specified              (in V)
Vt_spec    = str2double(answer1{5});                         % Vt at which Idsat and Ileak are specified               (in V)
tox        = str2double(answer1{6}).*1e-9;                   % Effective oxide thickness                               (in m)
alpha      = str2double(answer1{7});                         % Alpha value of the power-law MOSFET model
drive_p_div_n  = str2double(answer1{8});                     % Ratio of drive currents of pMOS and nMOS
subvtslope_spec = str2double(answer1(9)).*1e-3;              % Subthreshold slope at 85 degree C                       (in mV/dec)
F1          = F;                                             % Minimum wire pitch F1 is many times not the same as F. Parameter gives flexibility

% Interconnect and package technology parameters

wire_parameters = {'Please enter interconnect and package technology parameters                                                                                                   Relative permittivity of dielectric:','Resistivity (in ohm-m):', 'Wire aspect ratio:', 'Reflectivity co-efficient at grain boundaries for Cu:', 'Specularity parameter for Cu:','Number of power pads', 'Average distance between two power pads', 'Length of a pad', 'IR drop limit (in %age of Vdd)'};
dlg_title = 'Enter interconnect and package technology parameters';
num_lines = 1;
def = {'2','1.95e-8', '2', '0.5', '0.5','600', '300e-6', '50e-6', '0.02'};
options.Resize = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
answer2 = inputdlg(wire_parameters,dlg_title,num_lines,def, options);

er                = str2double(answer2{1});               % Dielectric permittivity
rho               = str2double(answer2{2});               % Resistivity of copper                                   (in ohm-m)
ar                = str2double(answer2{3});               % Aspect ratio of wiring levels
R                 = str2double(answer2(4));               % Reflectivity co-efficient at grain boundaries for Cu
p_size            = str2double(answer2(5));               % Specularity parameter
npower_pads       = str2double(answer2{6});               % Number of power pads
pad_to_pad_distance = str2double(answer2{7});             % Average distance from one power pad to the next
pad_length        = str2double(answer2{8});               % Length of a pad
ir_drop_limit     = str2double(answer2(9));               % IR drop limit in percentage, half of this is for global and half for local
  
% Design parameters

design_parameters = {'Please enter design parameters                                                                                                       Average fan-out of logic gates:','Router efficiency:', 'Repeater efficiency:', 'Fraction of clock cycle lost due to skew and process variations:','Biggest size H tree that needs to be driven with acceptable slew in global metal levels (in mm):' ,'Number of latches driven by a local clock buffer:', 'Clock factor (number of latches = clock factor x total number of gates/number of gates on a critical path)' , 'Fraction of local clock power saved by clock gating'   };
dlg_title = 'Enter design parameters';
num_lines = 1;
def = {'3', '.5', '.5','.2','3','20','1','0.4'};
options.Resize = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
answer3 = inputdlg(design_parameters,dlg_title,num_lines,def, options);

router_eff        = str2double(answer3{2});                   % Router efficiency 
rep_eff           = str2double(answer3{3});                   % Repeater efficiency
fo                = str2double(answer3{1});                   % Average fan out of logic gates
margin            = str2double(answer3{4});                   % Percentage of clock cycle lost due to process variations and clock skew
D                 = str2double(answer3{5}).*1e-3;             % Max span of H tree that needs to be driven       
latches_per_buffer = str2double(answer3{6});                  % Latches per buffer
clock_factor      = str2double(answer3{7});                   % Clock factor. Number of latches = clock factor x total number of gates / number of gates on a critical path
clock_gating_factor = str2double(answer3{8});                 % Percentage of local clock power saved by clock gating
kai = 4./(fo+3);                                              % Point-to-point to net length correction factor = 4/(f.o+3)
alpha_wire = fo./(fo+1);                                      % alpha_wire is f.o/(f.o+1)

% Ask for file name to output data to

output_file = {'Please enter output file name'};
dlg_title = 'Output file description';
num_lines = 1;
def = {'output.txt'};
options.Resize = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
answer4 = inputdlg(output_file, dlg_title,num_lines,def, options);

%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------










%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% LOGIC GATE MODELING

% Find the drive resistance and input capacitance of a min size inverter
ro = ro_calc(Vdd, Vt, Vdd_spec, Vt_spec, Idsat_spec, alpha);
co = co_calc(tox, F);

% Obtain wire capacitance per unit length
H = F;
W = F;
T = ar.*F;
S = F;
cg = cg_calc(W, T, H, S, er);
cm = cm_calc(W, T, H, S, er);

% Find average wire length and device size
[device_width reach_clock_frequency_flag pgates] = two_input_nand_gate_sizing(ngates, A, cg, cm, ro, tox, F, ncp, f, margin, drive_p_div_n, k, p , fo);

% If clock frequency is too high for a specified logic depth, Vdd and Vt, program needs to give an error message 
if (reach_clock_frequency_flag == 1) 
    errordlg('The specified clock frequency cannot be reached with this logic depth, supply voltage and threshold voltage','Error');
    return;
end

% Computes total area needed for logic gates and available area for repeaters, decaps, etc

area_single_logic_gate = area_two_input_nand_gate_calc(F, device_width);
total_area_logic_gates = area_single_logic_gate.*ngates;
nsockets= ngates./pgates;
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------


% Since the on-chip power delivery network cannot be designed without knowing the
% power, an iterative process is used to design the wiring network. An
% initial value of power is assumed, and the interconnect network is
% obtained. Following this, the power predicted by IntSim is compared to
% the initial guess. If it is different, the initial guess is refined till
% the simulation converges.

total_estimated_power =120;
total_estimated_power_dummy = total_estimated_power;
total_number_repeaters = 0;
iteration = -1;
total_power = 0;

while(abs(total_estimated_power_dummy-total_power)>.5)

  
iteration = iteration+1;
old_total_power = total_estimated_power_dummy;

clear net_wire_efficiency length_max pitch pitch_updated_with_repeaters length_max_updated_with_repeaters net_wire_efficiency_repeaters number_repeaters



%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% REZA SARVARI'S MODEL FOR CALCULATING POWER VIA BLOCKAGE ASSUMING W(Metal 1)=2F1, W(Metal 2)=2F1 AND POWER/GROUND WIRE EFFICIENCY=15%
% Ref: Paper at the Intl. Interconnect Technology Conference '2007

% Gives the integral of the length times wire length distribution (for different length values)
gamma=2*ngates*(1-(ngates^(p-1)))/(-(nsockets^p)*((1+(2*p)-(2^(2*p-1)))/(p*(2*p-1)*(p-1)*(2*p-3)))-(1/(6*p))+(2*sqrt(nsockets)/((2*p)-1))-nsockets/(p-1));
kk=gamma*alpha_wire*k;
i=[1:1:2*sqrt(nsockets)];
y1=(kk/2)*((1/3)*i.*i.*i-2*sqrt(nsockets)*i.*i+2*nsockets.*i).*i.^(2*p-4);
y2=(kk/6)*(2*sqrt(nsockets)-i).^3.*i.^(2*p-4);
y=(y1.*(sign(sqrt(nsockets)-i)+1)+y2.*(sign(i-sqrt(nsockets))+1))/2;
intg_number = cumsum(y);
intg_length = cumsum(i.*y);

% Find total wire length to calculate power
total_length = intg_length(floor(2.*nsockets.^.5));

% Total power defined by user

[ leakage_power_two_input_nand dyn_power_two_input_nand ] = power_calc_two_input_nand(device_width, F,tox, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, Vdd, Vt, f);
leakage_power_logic_gates = ngates.*leakage_power_two_input_nand;
dyn_power_logic_gates = ngates.*dyn_power_two_input_nand;
power_wires = .5.*a.* 4./(fo+3).*total_length.*((A./nsockets).^.5).*(2.*cg+2.*cm).*Vdd.^2.*f;
[leakage_power_inv dyn_power_inv] = power_calc_inv(co, Vdd, Vt, f, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, drive_p_div_n);

% Clock power
nlatches = clock_factor.*ngates./ncp;
clatches = nlatches.*device_width.*2.*co;
clocal_clock = ((A.*nlatches./latches_per_buffer).^.5).*(2.*cg+2.*cm);
cbuffer = .33.*(clocal_clock+clatches);
clock_power = ((clatches+clocal_clock+cbuffer).*Vdd.^2.*f+cbuffer./co.*leakage_power_inv).*(1-clock_gating_factor);

max_power_repeaters = total_estimated_power- power_wires - dyn_power_logic_gates - leakage_power_logic_gates - clock_power;


% Maximum dc current per gate
idc = 1./a.*(dyn_power_logic_gates+power_wires+clock_power+max_power_repeaters.*dyn_power_inv./(dyn_power_inv+leakage_power_inv))./ngates./Vdd;

% Obtain m and n, a logic block's size for Reza's model
[ area_two_input_nand_gate ] = area_two_input_nand_gate_calc( F, device_width );
m = 1./F1.*(17./6.*area_two_input_nand_gate).^.5;
n = 1./F1.*(area_two_input_nand_gate./17.*6).^.5;

% Resisitivity computation considering size effects and W(Metal 1)=2F1 AND W(Metal 2)=2F1
% R = Reflectivity co-efficient at grain boundaries, mean free path of Cu is 38nm, p_size is the specularity parameter 
alpha_size_power = 38e-9./(2.*F1).*R./(1-R);
rho_size_power = 1.67e-8.*(1/3./(1./3-alpha_size_power./2+alpha_size_power.^2.-alpha_size_power.^3.*log(1+1./alpha_size_power))+3./8.*1.2.*(1-p_size).*(1+ar)./ar.*38e-9./(2.*F1));

% Finding px and py, the pitches of power vias. Wiring efficiency of power and ground set as 15%
Vir_local = ir_drop_limit./2.*Vdd;
ew_power_ground = 0.15;
px = ((n.*F1).^2+4.*n.*F1.^3.*ar.*Vir_local./idc./rho_size_power).^.5 - n.*F1;
py = (m.*ew_power_ground./2-1).*px;

% Half the below vias are used for power and the other half are used for ground
nv_power_ground = 2.*A./px./py;

%fprintf('Reza model passed\n');
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------












%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% LOCAL INTERCONNECT MODELING

% s(F/2) is the design rule for vias
s = 3;
pitch(1) = 2.*F1;
for l = floor(2.*nsockets.^.5):-1:1
    % Effective wire efficiency computation
    nv = 2.*(intg_number(floor(2.*nsockets.^.5))-intg_number(floor(l)))+2.*total_number_repeaters;
    via_blockage_factor = (nv.*(pitch(1)+s.*F1./2).^2./A).^.5;
    net_wire_efficiency(1) = router_eff - ew_power_ground - via_blockage_factor ;
    supply = net_wire_efficiency.*2.*A./kai./pitch(1)./(A./nsockets).^.5;
    demand = intg_length(floor(l))-intg_length(floor(1));
    if (demand<supply)
        length_max(1)=l;
        net_wire_efficiency(1)=net_wire_efficiency(1);
        break;
    end
end

%fprintf('Local interconnect okay\n');

%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------










%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% ARRANGE WIRES WITHOUT REPEATERS

l_last = length_max(1); % Set the length of the longest wire in the first tier as the max length
tier = 1; % First tier arrangement complete
repeaters_howmany = 2.*total_number_repeaters;

% Second and higher tier design
% This loop runs only when the longest wire in the last routed tier is shorter than the max wire length of the die
while (l_last<(2.*(nsockets^.5)))                        
    
    % First start off with pitch = 2F
    pitch(tier+1) = 2.*F1;
    
    for l = l_last:1:2.*nsockets.^.5
        
    net_wire_efficiency(tier+1) =  router_eff  - ((nv_power_ground +2.*total_number_repeaters+(2.*(intg_number(floor(2.*nsockets.^.5))-intg_number(floor(l))))).*(pitch(tier+1)+s.*F1./2).^2./A).^.5;
    value1 = net_wire_efficiency(tier+1).*2.*A./kai./pitch(tier+1)./(A./nsockets).^.5;
    
         if ((intg_length(floor(l))-intg_length(floor(l_last)))>value1)
         length_max(tier+1)=l;
         %fprintf('It is going into the loop where the pitch is set as 2F\n');
         break;
         else length_max(tier+1)=2.*nsockets.^.5;
         end
    end
    

    % Then see if the beta value is less than 0.25
    alpha_size = 38e-9./(pitch(tier+1)./2).*R./(1-R);
    rho_size = 1.67e-8.*(1/3./(1./3-alpha_size./2+alpha_size.^2.-alpha_size.^3.*log(1+1./alpha_size))+3./8.*1.2.*(1-p_size).*(1+ar)./ar.*38e-9./(pitch(tier+1)./2));

    if ((f.*4.4.*rho_size.*2.*(cg+cm)./(T./W)./pitch(tier+1).^2.*A./nsockets.*length_max(tier+1).^2)<0.25)
    pitch(tier+1)=2.*F1;
    length_max(tier+1)=length_max(tier+1);
    %fprintf('The value of beta is lower than 0.25\n');
    l_last = length_max(tier+1);
    
    else
        %fprintf('The value of beta is higher than 0.25\n');
        for l = l_last:1:2.*nsockets.^.5
        beta=1-margin;
        p1_new=0;
        p1 = 2.*((1.1.*rho./(T./W).*2.*(cg+cm).*f./beta.*A./nsockets).^.5).*l;
        p1_dummy = p1;
        while (abs(p1_dummy-p1_new)>1e-10)
        alpha_size = 38e-9./(p1./2).*R./(1-R);
        rho_size = 1.67e-8.*(1/3./(1./3-alpha_size./2+alpha_size.^2.-alpha_size.^3.*log(1+1./alpha_size))+3./8.*1.2.*(1-p_size).*(1+ar)./ar.*38e-9./(p1./2));
        p1_new= 2.*((1.1.*rho_size./(T./W).*2.*(cg+cm).*f./beta.*A./nsockets).^.5).*l;
        p1_dummy = p1;
        p1=(p1_new+p1)./2;
        end
        
        dummy_wire_eff = router_eff  - ((2.*total_number_repeaters+nv_power_ground +(2.*(intg_number(floor(2.*nsockets.^.5))-intg_number(floor(l))))).*(p1+s.*F1./2).^2./A).^.5;
        value1 = dummy_wire_eff.*2.*A./kai./p1./(A./nsockets).^.5;
        %demand = intg_length(floor(l))-intg_length(floor(l_last)) % debug
        
            if ((intg_length(floor(l))-intg_length(floor(l_last)))>value1)
            length_max(tier+1)=l;
            %fprintf('It is going into the loop where the wires are long\n');
            pitch(tier+1)=p1;
            net_wire_efficiency(tier+1) = dummy_wire_eff;
            dummy_l_last = length_max(tier+1);
            break;
            end
                     
           
        end
    end
    
    if (pitch(tier+1)<2.*F1)
        %fprintf('The long wires have pitches smaller than minimum feature size\n');
        pitch(tier+1)=2.*F1;
        for l = l_last:1:2.*nsockets.^.5
         net_wire_efficiency(tier+1) =  router_eff  - ((2.*total_number_repeaters+nv_power_ground +(2.*(intg_number(floor(2.*nsockets.^.5))-intg_number(floor(l))))).*(pitch(tier+1)+s.*F1./2).^2./A).^.5;
         value1 = net_wire_efficiency(tier+1).*2.*A./kai./pitch(tier+1)./(A./nsockets).^.5;
         if ((intg_length(floor(l))-intg_length(floor(l_last)))>value1)
         length_max(tier+1)=l;
         l_last = length_max(tier+1);
         break;
         end
        end
    else l_last = dummy_l_last;
    end

    %fprintf('The length of the longest wire is %f\n', l_last);
    if (tier == 40) return; end % debug statement
    
    % Termination criterion
        beta=1-margin;
        p1_new=0;
        p1 = 2.*((1.1.*rho./(T./W).*2.*(cg+cm).*f./beta.*A./nsockets).^.5).*2.*nsockets.^.5;
        p1_dummy = p1;
        while (abs(p1_dummy-p1_new)>1e-10)
        alpha_size = 38e-9./(p1./2).*R./(1-R);
        rho_size = 1.67e-8.*(1/3./(1./3-alpha_size./2+alpha_size.^2.-alpha_size.^3.*log(1+1./alpha_size))+3./8.*1.2.*(1-p_size).*(1+ar)./ar.*38e-9./(p1./2));
        p1_new= 2.*((1.1.*rho_size./(T./W).*2.*(cg+cm).*f./beta.*A./nsockets).^.5).*2.*nsockets.^.5;
        p1_dummy = p1;
        p1=(p1_new+p1)./2;
        end
        %dummy_wire_eff = router_eff  - (nv_power_ground.*p1.^2./A).^.5;
        dummy_wire_eff = 8;
        demand_last = intg_length(floor(2.*nsockets.^.5))-intg_length(floor(l_last));
        supply_last = dummy_wire_eff.*2.*A./kai./p1./(A./nsockets).^.5;
        value1 = (router_eff  - ((2.*total_number_repeaters+nv_power_ground +(2.*(intg_number(floor(2.*nsockets.^.5))-intg_number(floor(l_last))))).*(pitch(tier+1)+s.*F1./2).^2./A).^.5).*2.*A./kai./p1./(A./nsockets).^.5;
        if ((intg_length(floor(2.*nsockets.^.5))-intg_length(floor(l_last)))< supply_last)
        length_max(tier+2)= 2.*nsockets.^.5;
        pitch(tier+2)=p1;
        net_wire_efficiency(tier+2)=dummy_wire_eff;
        tier = tier+ kai.*p1.*((A./nsockets).^.5).*(intg_length(floor(2.*nsockets.^.5))-intg_length(floor(l_last)))./2./dummy_wire_eff./A;
        l_last=2.*nsockets.^.5;
        %fprintf('This is the loop where things terminate\n');
        
            
        end
    
    tier = tier+1;
    
    
end
% Test statements
pitch_no_repeaters = pitch;
length_max_no_repeaters = length_max;
net_wire_efficiency_no_repeaters = net_wire_efficiency;

%fprintf('Arrange wires without repeaters okay\n');
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------



 




%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% GLOBAL WIRE PITCH CALCULATION

% Ratio of widths of power and signal wires
kp=2;

% Ratio of widths of clock and signal wires
kc=4;

% Wiring efficiency considering only via blockage and router efficiency
ew = router_eff;

% Max slew allowable on clock wire
beta_clock = 0.25;

% Dimensions of wires
W_global = kc.*1e-6;
T_global = ar.*1e-6;
H_global = 1e-6.*ar;
S_global = 1e-6;

% Compute capacitance per unit length of a clock wire
c_clock = 2.*cg_calc(W_global, T_global, H_global, S_global, er)+2.*cm_calc(W_global, T_global, H_global, S_global, er);


% Global wire pitch considering only power and signal wires
global_pitch_power_signal = 2.*(kp+.5).*rho.*total_estimated_power./Vdd.*pad_to_pad_distance.^2./3.142./ew./A./ar./kp./(ir_drop_limit./2.*Vdd).*log(.65.*pad_to_pad_distance./pad_length);

% Clock wire pitch requirement
if (beta_clock./f./ro./co<15)
    beta_clock = 0.35; %this condition means clock frequencies are high, so inductive effects will improve the rise time
    global_pitch_clock = D./2.*((c_clock.*rho./ar./kc./ro./co).^.5)./(beta_clock./f./ro./co-11).*((72.6+4.4.*beta_clock./f./ro./co).^.5+11);
else
    global_pitch_clock = D./2.*((c_clock.*rho./ar./kc./ro./co).^.5)./(beta_clock./f./ro./co-11).*((72.6+4.4.*beta_clock./f./ro./co).^.5+11);
end

% Computing the actual global wire pitch needed
global_wire_pitch = max([global_pitch_power_signal global_pitch_clock]);

power_wire_efficiency = 2.*(kp+.5).*rho.*total_estimated_power./Vdd.*(pad_to_pad_distance.^2)./3.142./ar./kp./(ir_drop_limit./2.*Vdd)./global_wire_pitch.*log(.65.*pad_to_pad_distance./pad_length)./2./A;

net_wire_efficiency_repeaters(1) = router_eff - power_wire_efficiency;

% Minimum wire length in global levels
for l = 1:1:2.*nsockets.^.5
    value1 = net_wire_efficiency_repeaters(1).*2.*A./kai./global_wire_pitch./(A./nsockets).^.5;
    if ((intg_length(floor(2.*nsockets.^.5))-intg_length(floor(l)))<value1)
        lmin=l;
        break;
    end
end

% Number of repeaters, size of repeaters and power consumed by repeaters in global wire levels
length_global_wire_levels = (intg_length(floor(2.*nsockets.^.5))-intg_length(floor(lmin))).*kai.*(A./nsockets).^.5;
r = 4.*rho./ar./global_wire_pitch.^2;
c = 2.*cg+2.*cm;
size_rep_global = (ro.*c./r./co).^.5;
number_rep_global = .5.*((.4.*r.*c./.7./ro./co).^.5).*length_global_wire_levels;
area_rep_global = number_rep_global.*area_inv_calc(F,size_rep_global);
[leakage_power_inv dyn_power_inv] = power_calc_inv(co, Vdd, Vt, f, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, drive_p_div_n);
leakage_power_repeaters_global = number_rep_global.*size_rep_global.*leakage_power_inv;
dyn_power_repeaters_global = number_rep_global.*size_rep_global.*dyn_power_inv;
power_rep_global =  dyn_power_repeaters_global+leakage_power_repeaters_global;
max_power_repeaters = max_power_repeaters -  power_rep_global;
[leakage_power_inv dyn_power_inv] = power_calc_inv(co, Vdd, Vt, f, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, drive_p_div_n);

lmax = lmin;
%fprintf('Global wire pitch okay\n');
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------






%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% REPEATER INSERTION ALGORITHM

pitch_updated_with_repeaters(1)=global_wire_pitch;
length_max_updated_with_repeaters(1) = 2.*nsockets.^.5;
area_rep_total = area_rep_global;
net_wl_rep = number_rep_global.*area_rep_global;
leakage_power_repeaters = leakage_power_repeaters_global;
dyn_power_repeaters = dyn_power_repeaters_global;
available_area = A-ngates.*area_two_input_nand_gate-area_rep_global;
number_repeaters(1) = number_rep_global;
total_number_repeaters = number_rep_global;
phigate = dyn_power_inv./(dyn_power_inv+leakage_power_inv);

n = 2;
length_max_updated_with_repeaters(n) = lmax;
rep_flag = 1;

while (rep_flag == 1)
[ lmin pitch_rep  number_rep size_rep rep_flag area_rep power_rep net_wire_eff_for_this_level] = repeater_calc_edp( phigate, pgates, total_number_repeaters, nv_power_ground, leakage_power_inv, dyn_power_inv, R, p_size, max_power_repeaters, ar, lmax, ro, co, available_area, F, cg, cm , f, margin, rho, router_eff, A, ngates, p , alpha_wire, k, kai, s, F1);
test = rep_flag;

    if (test == 1)
    lmax = lmin;
    pitch_updated_with_repeaters(n) = pitch_rep;
    length_max_updated_with_repeaters(n+1) = lmax;
    area_rep_total = area_rep_total + area_rep;
    available_area = available_area-area_rep;
    net_wl_rep = net_wl_rep+number_rep.*size_rep;
    leakage_power_repeaters = net_wl_rep.*leakage_power_inv;
    dyn_power_repeaters = net_wl_rep.*dyn_power_inv;
    number_repeaters(n) = number_rep;
    net_wire_efficiency_repeaters(n) = net_wire_eff_for_this_level;
    total_number_repeaters = total_number_repeaters+number_rep;
    max_power_repeaters = max_power_repeaters - power_rep;
    n=n+1;
    end
end

% Test statements
pitch_updated_with_repeaters = pitch_updated_with_repeaters;
length_max_updated_with_repeaters = length_max_updated_with_repeaters;
net_wire_efficiency_repeaters = net_wire_efficiency_repeaters;
%total_number_repeaters = total_number_repeaters;
%area_rep_total = area_rep_total;
%number_repeaters = number_repeaters;
%net_wl_rep=net_wl_rep;
%nv_power_ground;
%fprintf('Repeater insertion okay\n');
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------





%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% COMPUTE TOTAL POWER


total_power = leakage_power_logic_gates+ leakage_power_repeaters + dyn_power_logic_gates + dyn_power_repeaters + power_wires + clock_power;
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
new_total_power = total_power;
total_estimated_power_dummy = total_estimated_power;
total_estimated_power = (total_estimated_power+total_power)./2;

end












%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% DATA OUTPUT

% Combines data from the repeater insertion algorithm and wire arrangement without repeaters

index=0;
% m1 is the index for the unrepeatered case
% n1 is the index for the repeated case
for m1=1:length(length_max_no_repeaters)
    
    for n1=1:1:length(length_max_updated_with_repeaters);
        Length_unrepeated_case = length_max_no_repeaters(m1);
        Length_repeated_case = length_max_updated_with_repeaters(n1);
    if (length_max_no_repeaters(m1)>length_max_updated_with_repeaters(n1))     
        index = m1;
        break;
    end
    
    end
    if index>0 break; 
    end
    
end
for m2=1:index
    pitch_final1(m2) = pitch_no_repeaters(m2);
    wiring_eff_final(m2) = net_wire_efficiency_no_repeaters(m2);
    m4=1;
    for m3=length(pitch_updated_with_repeaters):-1:1
        pitch_updated_with_repeaters_reverse(m4) = pitch_updated_with_repeaters(m3);
        m4=m4+1;
    end
    m5=1;
    for m6=length(net_wire_efficiency_repeaters):-1:1
        net_wire_efficiency_repeaters_reverse(m5) = net_wire_efficiency_repeaters(m6);
        m5=m5+1;
    end
    pitch_final = [pitch_final1 pitch_updated_with_repeaters_reverse];
    wire_efficiency_final = [wiring_eff_final net_wire_efficiency_repeaters_reverse];
end
pitch_after_repeater_insertion = pitch_final;
wire_efficiency_after_repeater_insertion = wire_efficiency_final;
pitch_final_for_print=sort(pitch_final,'ascend');
subplot(2,1,1);
bar(pitch_final_for_print.*1e9);
title({'   ';['Frequency =',num2str(f.*1e-9), 'GHz, Die Area =', num2str(A.*1e6), 'sq mm, ', num2str(ngates.*1e-6),' million gates'];'  '});
xlabel('Pair of metal levels');
ylabel('Pitch in nm');

% Power calculation
[ leakage_power_two_input_nand dyn_power_two_input_nand ] = power_calc_two_input_nand(device_width, F,tox, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, Vdd, Vt, f);
leakage_power_logic_gates = ngates.*leakage_power_two_input_nand;
dyn_power_logic_gates = ngates.*dyn_power_two_input_nand;
[leakage_power_inv dyn_power_inv] = power_calc_inv(co, Vdd, Vt, f, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, drive_p_div_n);
dyn_power_repeaters = dyn_power_repeaters;
leakage_power_repeaters = leakage_power_repeaters;
power_wires = .5.*a.* 4./(fo+3).*total_length.*((A./nsockets).^.5).*(2.*cg+2.*cm).*Vdd.^2.*f;

% Clock power
nlatches = clock_factor.*ngates./ncp;
clatches = nlatches.*device_width.*2.*co;
clocal_clock = ((A.*nlatches./latches_per_buffer).^.5).*(2.*cg+2.*cm);
cbuffer = .33.*(clocal_clock+clatches);
clock_power = (1-clock_gating_factor).*((clatches+clocal_clock+cbuffer).*Vdd.^2.*f+cbuffer./co.*leakage_power_inv);

total_power = leakage_power_logic_gates+ leakage_power_repeaters + dyn_power_logic_gates + dyn_power_repeaters + power_wires+clock_power;
pie_plot=[dyn_power_logic_gates leakage_power_logic_gates dyn_power_repeaters leakage_power_repeaters power_wires clock_power];
subplot(2,1,2);
pie(pie_plot,{'Active-logic','Leakage-logic','Active-repeaters','Leakage-repeaters','Wires','Clock'});
title({'  ';['Total power =', num2str(total_power), 'W'];'   '});
colormap summer

%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------


%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% OUTPUT A TEXT FILE WITH THE RESULTS
fid = fopen(answer4{1},'wt');
count0 = fprintf(fid, '--------------------------------------------------------------------------------------------------------------------------------\n');
count1 = fprintf(fid, 'Results from INTsim\n');
count2 = fprintf(fid, '--------------------------------------------------------------------------------------------------------------------------------\n\n');
count3 = fprintf(fid, 'Pitches of different pairs of metal levels after repeater insertion (in nm):\n');
for m1 = 1:1: length(pitch_final_for_print)-1
count4 = fprintf(fid,'%f, ', pitch_final_for_print(m1).*1e9);
end
count5 = fprintf(fid,'%f\n\n', pitch_final_for_print(length(pitch_final_for_print)).*1e9);
count6 = fprintf(fid, 'Number of metal levels needed after repeater insertion: %d\n\n', length(pitch_final_for_print).*2);
count7 = fprintf(fid, 'Area- \nLogic gate area = %f sq mm, ', total_area_logic_gates.*1e6);
count8 = fprintf(fid, 'Repeater area = %f sq mm, ', area_rep_total.*1e6);
count9 = fprintf(fid, 'Area available for decaps and clock circuitry = %f sq mm\n\n', available_area.*1e6);
count10 = fprintf(fid, 'Power- \nLeakage power: Logic gates = %f W, Repeaters = %f W\n', leakage_power_logic_gates, leakage_power_repeaters);
count11 = fprintf(fid, 'Dynamic power: Logic gates = %f W, Repeaters = %f W, Interconnects = %f W, Clock = %f W\n', dyn_power_logic_gates, dyn_power_repeaters, power_wires, clock_power);
count12 = fprintf(fid, 'Total power = %f W\n\n', total_power);
count13 = fprintf(fid, 'Wire efficiency (from Metal1 to Metaln)- \n');
for m1 = 1:1: length(wire_efficiency_after_repeater_insertion)-1
count14 = fprintf(fid,'%f, ', wire_efficiency_after_repeater_insertion(m1));
end
count15 = fprintf(fid,'%f\n\n', wire_efficiency_after_repeater_insertion(length(wire_efficiency_after_repeater_insertion)));
count17 = fprintf(fid, 'Input parameters:\n');
count18 = fprintf(fid, 'Vdd = %gV, Vt = %g V, Clock frequency = %g GHz, Number of gates on a critical path = %g,  Activity factor = %g\n', Vdd, Vt, f.*1e-9, ncp, a); 
count19 = fprintf(fid, 'Rent constant k = %g, Rent constant p = %g,Die area = %g sq mm, Number of gates = %g million \n', k, p, A.*1e6, ngates.*1e-6);
count20 = fprintf(fid, 'Feature size = %g nm, Saturation drain current of a minimum size nFET = %g uA/um, Leakage current of a minimum size nFET = %g uA/um\n', F.*1e9, Idsat_spec./F, Ileak_spec./F);
count21 = fprintf(fid, 'Vdd and Vt at which these currents are specified = %g V and %g V, Subthreshold slope at 85 Celsius = %g mV/dec\n',Vdd_spec, Vt_spec,subvtslope_spec);
count22 = fprintf(fid, 'Effective oxide thickness = %g nm, Alpha of the power law MOSFET model = %g, Ratio of drive currents of pMOS to nMOS = %g\n', tox.*1e9, alpha, drive_p_div_n );
count23 = fprintf(fid, 'Dielectric permittivity = %g, Wire resistivity without size effects = %g ohm-m, Specularity parameter = %g, Reflectivity coefficient at grain boundaries for Cu=%g\n',er, rho, R, p_size); 
count24 = fprintf(fid, 'Wire aspect ratio = %g, Number of power pads = %g, Pad to pad distance = %g um, Pad length = %g um, IR drop limit = %g percent\n', ar, npower_pads, pad_to_pad_distance.*1e6, pad_length.*1e6, ir_drop_limit.*100);  
count25 = fprintf(fid, 'Router efficiency = %g percent, Average fan-out = %g, Percentage of clock cycle lost to skew and process variations = %g percent\n',router_eff.*100, fo, margin.*100);
count26 = fprintf(fid, 'Max span of H tree that needs to be driven = %g mm, Latches per buffer = %g, Clock factor = %g, Percentage of local clock power saved by clock gating = %g percent\n', D.*1e3, latches_per_buffer, clock_factor, clock_gating_factor);
count16 = fprintf(fid, '-------------------------------------------------------------------------------------------------------------------------------\n\n');
%---------------------------------------------------------------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------------------------------------------------------------

