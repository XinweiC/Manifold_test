function [ lmin pitch_rep  number_rep size_rep rep_flag area_rep power_rep net_wire_eff_for_this_level] = repeater_calc_edp( phigate, pgates, total_number_repeaters, nv_power_ground, leakage_power_inv, dyn_power_inv, R, p_size, max_power_repeaters, ar, lmax, ro, co, available_area, F, cg, cm , f, margin, rho, router_eff, A, ngates, p , alpha_wire, k, kai,s ,F1)
%repeater_calc Inserts repeaters into the tier if pitch after repeater insertion>=2F, if the number and size of repeaters>1, and area needed<available area
%   This is a repeater insertion function

c = 2.*cg+2.*cm;
nsockets = ngates./pgates;
p1_new=0;
p1  = 5.45.*lmax./(1-margin).*f.*(c.*rho./ar.*ro.*co.*A./nsockets).^.5;
p1_dummy = p1;
gamma_rep = (.73+.07.*log(phigate)).^2;
delta_rep = (.88+.07.*log(phigate)).^2;
while (abs(p1_dummy-p1_new)>1e-10)
        alpha_size = 38e-9./(p1./2).*R./(1-R);
        rho_size = 1.67e-8.*(1/3./(1./3-alpha_size./2+alpha_size.^2.-alpha_size.^3.*log(1+1./alpha_size))+3./8.*1.2.*(1-p_size).*(1+ar)./ar.*38e-9./(p1./2));
        p1_new = (.7./delta_rep+.7.*gamma_rep+.7.*delta_rep+.4./gamma_rep).*2.*lmax./(1-margin).*f.*(c.*rho_size./ar.*ro.*co.*A./nsockets).^.5;
        p1_dummy = p1;
        p1=(p1_new+p1)./2;
end
        
%pitch_rep = 5.*lmax.*(A./(nsockets)).^.5.*f./(1-margin).*((ro.*co.*c.*rho).^.5);
pitch_rep = p1;

%---------------------------------------------------------------------------------------------------------------------------------------------------------------
% Gives the integral of the length times wire length distribution (for different length values)

gamma=2*ngates*(1-(ngates^(p-1)))/(-(nsockets^p)*((1+(2*p)-(2^(2*p-1)))/(p*(2*p-1)*(p-1)*(2*p-3)))-(1/(6*p))+(2*sqrt(nsockets)/((2*p)-1))-nsockets/(p-1));
kk=gamma*alpha_wire*k;

i=[1:1:2*sqrt(nsockets)];
y1=(kk/2)*((1/3)*i.*i.*i-2*sqrt(nsockets)*i.*i+2*nsockets.*i).*i.^(2*p-4);
y2=(kk/6)*(2*sqrt(nsockets)-i).^3.*i.^(2*p-4);
y=(y1.*(sign(sqrt(nsockets)-i)+1)+y2.*(sign(i-sqrt(nsockets))+1))/2;
intg=cumsum(i.*y);
intg_number = cumsum(y);

%------------------------------------------------------------------------------------------------------------------------------------------------------------

net_wire_eff_for_this_level = router_eff   - (( 2.*total_number_repeaters+nv_power_ground +(2.* (  intg_number(floor(2.*nsockets.^.5))   - intg_number(floor(lmax))    ) )).*(pitch_rep+s.*F1./2).^2./A).^.5;


%------------------------------------------------------------------------------------------------------------------------------------------------------------
% % Find the minimum length of wire routed in this repeater inserted level
for l = 1:1:2.*nsockets.^.5
    value1 = net_wire_eff_for_this_level.*2.*A./kai./pitch_rep./(A./nsockets).^.5;
    if (intg(floor(lmax))-intg(floor(l)) )<value1
        lmin=l;
        break;
    end
end
%------------------------------------------------------------------------------------------------------------------------------------------------------------
alpha_size = 38e-9./(pitch_rep./2).*R./(1-R);
rho_size = 1.67e-8.*(1/3./(1./3-alpha_size./2+alpha_size.^2.-alpha_size.^3.*log(1+1./alpha_size))+3./8.*1.2.*(1-p_size).*(1+ar)./ar.*38e-9./(pitch_rep./2));
r = 4.*rho_size./ar./pitch_rep.^2;
gamma_rep = (.73+.07.*log(phigate)).^2;
delta_rep = (.88+.07.*log(phigate)).^2;
total_length = (intg(floor(lmax))-intg(floor(lmin))).*kai.*(A./nsockets).^.5;
size_rep = delta_rep.*(ro.*c./r./co).^.5;
number_rep = gamma_rep.*((r.*c./ro./co).^.5).*total_length;
number_rep_longest = gamma_rep.*((r.*c./ro./co).^.5).*lmax.*kai.*(A./nsockets).^.5;
number_rep_shortest = gamma_rep.*((r.*c./ro./co).^.5).*lmin.*kai.*(A./nsockets).^.5;
%fprintf('New tier');
area_rep = number_rep.*area_inv_calc(F,size_rep);
lmin_min = 1./1.1.*(ro.*co./r./c).^.5.*(.7./delta_rep+.7.*gamma_rep+.7.*delta_rep+.4./gamma_rep);
lmin_here = lmin.*(A./nsockets).^.5;
%available_area = available_area;
power_rep = (leakage_power_inv+dyn_power_inv).*size_rep.*number_rep;
pitch_rep = pitch_rep;
%fprintf('The pitch needed for repeaters is %f\n', pitch_rep);
if (area_rep>=available_area)
%fprintf('Required area for adding repeaters not enough\n');
end
if ((power_rep>=max_power_repeaters))
    %fprintf('Power needed for repeaters, %f W,  too high and the max power is %f\n', power_rep, max_power_repeaters);
end
if (pitch_rep<=2.*F)
    %fprintf('Pitch of repeated wire becomes smaller than minimum feature size\n');
end

%if ((area_rep<available_area)&(power_rep<max_power_repeaters)&(pitch_rep>=2.*F)&(size_rep>=1)&(lmin_here>lmin_min))
if ((area_rep<available_area)&(pitch_rep>=2.*F)&(size_rep>=1)&(lmin_here>lmin_min))
    rep_flag = 1;
else rep_flag=0;
end

pitch_rep = pitch_rep;
min_wire_pitch = 2.*F;
%disp(rep_flag);


