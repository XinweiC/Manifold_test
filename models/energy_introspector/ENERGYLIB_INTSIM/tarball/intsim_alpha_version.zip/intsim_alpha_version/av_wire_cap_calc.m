function [ av_wire_cap ] = av_wire_cap_calc( cg, cm, k, p, A, ngates, pgates, fo )
%av_wire_cap Computes wire capacitance that needs to be driven by an
%average size gate

%------------------------------------------------------------------------
%   Reference: R. Venkatesan, PhD thesis, Georgia Tech, 2003
%   Available at www.ece.gatech.edu/research/labs/gsigroup under the
%   publications section
%------------------------------------------------------------------------

nsockets = ngates./pgates;
lavg_nr = (((p-.5)./p-(nsockets).^.5-(p-.5)./6./((nsockets).^.5)./(p+.5)+(nsockets.^p).*((-p-1+4.^(p-.5))./2./(p+.5)./p./(p-1)) ));
lavg_dr = (nsockets.^(p-.5)).*(-2.*p-1+2.^(2.*p-1))./2./p./(p-1)./(2.*p-3)-(p-.5)./6./p./(nsockets).^.5+1-(p-.5).*(nsockets.^.5)./(p-1);
lavg = lavg_nr./lavg_dr.*(pgates.^.5);
av_wire_cap = 4.*fo./(fo+3).*lavg.*((A./ngates).^.5).*(2.*cg+2.*cm);