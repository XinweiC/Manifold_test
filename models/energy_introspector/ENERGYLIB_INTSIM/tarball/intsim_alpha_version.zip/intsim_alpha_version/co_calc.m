function [co ] = co_calc( tox, F )
%co_calc Computes the input capacitance of a minimum size inverter
%   Assuming the beta ratio is 2, this function computes the input capacitance of a minimum size inverter

beta_ratio_inverter = 2;
eo = 8.854e-12;
Cox = 3.9.*eo./tox;
co = (F.^2).*Cox.*(1+beta_ratio_inverter);
