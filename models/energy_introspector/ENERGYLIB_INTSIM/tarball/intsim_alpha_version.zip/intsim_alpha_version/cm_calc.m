function [ cm ] = cm_calc( W, T, H, S, er )
%cm_calc Computes the ground capacitance per unit length of a wire
%   H is the ILD thickness, S is the spacing between wires, T is the wire thickness, W is the wire width
%------------------------------------------------------------------------
%   Reference: R. Venkatesan, PhD thesis, Georgia Tech, 2003
%   Available at www.ece.gatech.edu/research/labs/gsigroup under the
%   publications section
%------------------------------------------------------------------------

eo = 8.854e-12;
cm = er.*eo.*(T./S.*(1-1.897.*2.718.^(-H./.31./S-T./2.474./S)+1.302.*2.718.^(-H./.082./S)-.1292.*2.718.^(-T./1.326./S))+1.722.*(1-.6548.*2.718.^(-W./.3477./H)).*2.718.^(-S./.651./H));
