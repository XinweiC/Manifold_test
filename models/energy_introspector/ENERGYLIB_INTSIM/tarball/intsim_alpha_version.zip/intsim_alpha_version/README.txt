README file

1. Open matlab
2. Under the "current directory" option in matlab, type the directory in which all of intsim's files are stored. 
   For example, if all of intsim's files are stored in C:\intsim, make C:\intsim the current directory for matlab.
3. Type "intsim" on the command prompt
4. Input all parameters of the system to be modeled in the GUI
5. The text output of the program will be stored in the current directory in whatever filename you specify. 
   A graphical output is also provided for convenience.

For more details on the CAD tool, please refer the following paper:
Deepak C. Sekar, Azad Naeemi, Reza Sarvari, Jeffrey A. Davis, James D. Meindl, "IntSim: A CAD tool for optimization
of multilevel interconnect networks", Proc. Intl. Conference on Computer-Aided Design, Nov. 2007.

A copy of this paper is included in the files available for download. 