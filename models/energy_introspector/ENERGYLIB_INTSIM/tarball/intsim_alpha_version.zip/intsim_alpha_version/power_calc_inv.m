function [leakage_power_inv dyn_power_inv] = power_calc_inv(co, Vdd, Vt, f, a, Ileak_spec, Vdd_spec, Vt_spec, subvtslope_spec, drive_p_div_n)
%POWER_CALC_INV This function calculates the power of a minimum feature size inverter
%   This function can be used to calculate power of a repeater




% Computes dynamic power
dyn_power_inv = .5.*a.*co.*Vdd.^2.*f;

% Computes leakage power
leakage_power_inv = .5.*(1+1./drive_p_div_n).*Vdd.*Ileak_spec./(10.^(-Vt_spec./subvtslope_spec)).*(10.^(-Vt./subvtslope_spec));
